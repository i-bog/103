
const express = require('express');
const router = express.Router();
const axios = require('axios')
require('dotenv').config()

/*
  transaction.js -- Router for the Transac app
*/

const RequestItem = require('../models/RequestItem')//renamed
const User = require('../models/User')


/*
this is a very simple server which maintains a key/value
store using an object where the keys and values are lists of strings

*/

isLoggedIn = (req,res,next) => {
  if (res.locals.loggedIn) {
    next()
  } else {
    res.redirect('/login')
  }
}


const { Configuration, OpenAIApi } = require("openai");
const key = process.env.OPENAI_API_KEY;
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,

});





    
//getting the users seed
router.get('/sandwich',isLoggedIn, async (req, res, next) => {
    res.render('sandwichView')

    
});

const get_resp = async(bread, ingre,rest) => {
    const openai = new OpenAIApi(configuration);

    const sandwichPrompt = "What is a good " + rest + " sandwich recipe with " + bread + " bread and " + ingre + 
    " as ingredients. Please add other ingredients that are " + rest
    

    const completion = await openai.createCompletion({
        model: "text-davinci-003",
        prompt: sandwichPrompt,
        max_tokens: 1024
    });

    return (completion.data.choices[0].text);
}




router.post('/sandwich',
isLoggedIn,
  async (req,res,next) => {
    console.log('getting sandwiches')
    console.log(req.body.foods)
    res.locals.items = await get_resp(req.body.bread, req.body.ingredients, req.body.foods);
    console.log(req.body.foods)
    //creating a requestitems for seeds
    const quest = new RequestItem(
        { searchName: req.body.bread + " bread, " + req.body.foods +": " + req.body.ingredients ,
          searchResult: res.locals.items,
          category: "sandwich",
          userId: req.user._id
        })
    await quest.save();//save the item
    res.render('sandwichResults')
}
)

router.get('/sandwich/search',
  isLoggedIn,
  async (req, res, next) => {
    res.locals.items=await RequestItem.find({userId:req.user._id}).sort({category:-1}).collation({locale: "en_US", caseLevel: true})

    res.render('search')

      
});

  module.exports = router;