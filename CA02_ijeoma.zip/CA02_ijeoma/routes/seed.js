

const express = require('express');
const router = express.Router();
const axios = require('axios')
require('dotenv').config()

const RequestItem = require('../models/RequestItem')//renamed
const User = require('../models/User')


const { Configuration, OpenAIApi } = require("openai");
const key = process.env.OPENAI_API_KEY;
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,

});

isLoggedIn = (req,res,next) => {
    if (res.locals.loggedIn) {
      next()
    } else {
      res.redirect('/login')
    }
  }


    
//getting the users seed
router.get('/seed',isLoggedIn, async (req, res, next) => {
    res.render('seedView')

    
});

const get_resp = async(seedPrompt, locationPrompt) => {
    const openai = new OpenAIApi(configuration);

    const fullPrompt = "When is the best time to plant " + seedPrompt + "seeds in " + locationPrompt 
    

    const completion = await openai.createCompletion({
        model: "text-davinci-003",
        prompt: fullPrompt,
        max_tokens: 1024,
    });
    console.log(completion.data.choices[0].text);

    return (completion.data.choices[0].text);
}





router.post('/seed',
isLoggedIn,
  async (req,res,next) => {
    console.log('getting seeds')
    const a =7
    const items = await get_resp(req.body.seedName, req.body.location);
    res.locals.items = items
    console.log(typeof items)
    
    //creating a requestitems for seeds
    const quest = new RequestItem(
        { searchName: req.body.seedName,
          searchResult: String(items),
          category: "plant-seed",
          userId: req.user._id
        })
    await quest.save();//save the item
    res.render('seedResults')
}
)

//goes to a page with all the searched seeds
router.get('/seed/search',
  isLoggedIn,
  async (req, res, next) => {
    res.locals.items=await RequestItem.find({userId:req.user._id}).sort({category:1}).collation({locale: "en_US", caseLevel: true})

    res.render('search')

      
});



  module.exports = router;
