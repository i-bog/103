/**
 * schema for Plant and Sandwich APIs
 * saved for the User
 */



'use strict';
const mongoose = require( 'mongoose' );
const Schema = mongoose.Schema;
const ObjectId = mongoose.Schema.Types.ObjectId;//id for the object

//defining something with mongoose, in js.
var requestSchema = Schema( {
  searchName: String,
  searchResult: String,
  category: String,
 

  userId: {type:ObjectId, ref:'user' }

  //verifies thats a psecific transaction for the user. 
} );
//we can change amount : Number later
module.exports = mongoose.model( 'RequestItem', requestSchema );