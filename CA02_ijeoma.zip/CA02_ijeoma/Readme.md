need to install npm dotenv
in the .env file put your own API KEY inside